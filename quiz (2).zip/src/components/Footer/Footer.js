import React from 'react'

const Footer = () => {
  return (
    <div style={{textAlign:'center',marginBottom:10}}>
      Made with love by Nagaveni
      <a
      href="https://www.youtube.com/watch?v=pxyCd86Yc6U"
      style={{curser:"pointer"}}
      ></a>
    </div>
  )
}

export default Footer
